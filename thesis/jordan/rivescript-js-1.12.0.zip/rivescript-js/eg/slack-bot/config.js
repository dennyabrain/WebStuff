"use strict";

// Configuration for the Slackbot.

module.exports = {
	// Auth Token. You can generate your token from
	// https://<slack_name>.slack.com/services/new/bot
	token: "...",

	// The bot's name. Messages that start with this word will be handled by
	// the bot (users can also @mention the bot by username).
	name: "admiral"
}
