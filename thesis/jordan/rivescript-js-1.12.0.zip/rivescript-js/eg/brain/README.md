# Example RiveScript Brain

This is the standard RiveScript demo brain that ships with all implementations
of RiveScript.

It implements an Eliza-like chatbot with additional replies that demonstrate
various features of RiveScript.
